package com.smartdatasolutions.test.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import com.smartdatasolutions.test.Member;
import com.smartdatasolutions.test.MemberImporter;

public class MemberImporterImpl implements MemberImporter {
  String id ,lastName,firstName,address,city,state,zip;
  Member member;
 
 
	public Member getMember() {
	return member;
       }
 

     public void setMember(Member member) {
	this.member = member;
      }
 

	@Override
	public List< Member > importMembers( File inputFile ) throws Exception {
		  FileWriter writer = null;
		 List< Member > memberlst = new ArrayList<Member>();
		 List<String> dublicateCheck = new ArrayList<String>();
		 String[] fields;

		/*
		 * Implement the missing logic
		 */

		try (BufferedReader br = new BufferedReader( new FileReader( inputFile ) )) {
			String line = br.readLine( );

			while ( line != null ) {
				
				line = br.readLine( );
			     	if (line==null)
				    {
		    	    break;
				}
				
			 
				    fields = line.split("\\s{2,}");
				    id = fields[0];
					if (!(dublicateCheck.contains(id)))
					{		    
		         	lastName = fields[1];
				    firstName = fields[2];
			        address = fields[3];
			        
			        if(fields[4].length()>18)
			        {
			        	city= fields[4].substring(0, 20);
			        	 state= fields[4].substring(20, 22);
						 zip= fields[5];
			        }
				 	
			        else
			        {
			        	 city= fields[4]; 
			        	 state= fields[5];
						 zip= fields[6];
			        }
			        dublicateCheck.add(id);
			        
			          member = new Member(id,lastName,firstName,address,city,state,zip); 
			          memberlst.add(member);
			         
				      writer = new FileWriter("C:\\Users\\hp\\Desktop\\"+ getMember().getState()+"_outputFile.csv", true);
				   
				      MemberExporterImpl m = new MemberExporterImpl();
				      writer.write("\r\n");
		 
				      m.writeMember(member, writer);
			}
		}
		}
		
		return memberlst;
	}
 
}
