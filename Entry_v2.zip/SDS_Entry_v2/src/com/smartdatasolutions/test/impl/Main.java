package com.smartdatasolutions.test.impl;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.smartdatasolutions.test.Member;
import com.smartdatasolutions.test.MemberExporter;
import com.smartdatasolutions.test.MemberFileConverter;
import com.smartdatasolutions.test.MemberImporter;

public class Main extends MemberFileConverter {
 
 

	@Override
	protected MemberExporter getMemberExporter( ) {
		// TODO
		return null;
	}

	@Override
	protected MemberImporter getMemberImporter( ) {
	 
		return null;
	}

	@Override
	protected List< Member > getNonDuplicateMembers( List< Member > membersFromFile ) {

		// TODO
		return null;
	}

	@Override
	protected Map< String, List< Member >> splitMembersByState( List< Member > validMembers ) {
		// TODO
		return null;
	}

 public static void main( String[] args ) {
		
	 
		  File file = new File("members.txt");
		  MemberImporterImpl memberImporterImpl = new MemberImporterImpl();
		  try {
			  memberImporterImpl.importMembers(file);
		  } catch (Exception e) {
			 
			e.printStackTrace();
		  }
	 	  
		
	}

}
